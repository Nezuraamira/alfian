# marketdata.py
import time
import datetime as dt
import pandas as pd
import yfinance as yf

# --- konfigurasi default (bisa di-override dari config.py) ---
BATCH_CHUNK = 12         # banyak ticker per sekali tembak (Yahoo aman ~10-20)
BACKOFFS = [2, 5, 10, 20, 40]  # detik
CACHE_TTL_SEC = 55       # selama < 1 menit, pakai cache supaya tak ngulang

# cache sederhana dalam-memori per (interval, period)
_cache = {}  # key: (interval, period) -> {"ts": utc, "df": DataFrame}

def _now_utc():
    return dt.datetime.now(dt.timezone.utc)

def _within_ttl(ts, ttl):
    return (_now_utc() - ts).total_seconds() < ttl

def _safe_download(tickers, interval, period):
    """
    Satu panggilan yfinance untuk banyak tickers.
    Return DataFrame bertingkat (MultiIndex kolom) -> kita normalkan kemudian.
    """
    last_err = None
    for i, slp in enumerate([0] + BACKOFFS):
        if slp:
            time.sleep(slp)
        try:
            df = yf.download(
                tickers=tickers,
                interval=interval,
                period=period,
                auto_adjust=True,
                progress=False,
                threads=False,      # penting! menghindari ban
                group_by="ticker"   # biar mudah dipisah
            )
            if isinstance(df, pd.DataFrame) and not df.empty:
                return df
            last_err = RuntimeError("Empty dataframe from Yahoo")
        except Exception as e:
            # yfinance rate-limit sering mengandung “Too Many Requests / rate limited”
            last_err = e
    raise last_err or RuntimeError("Download failed")

def fetch_batch(tickers, interval, period, cache_ttl=CACHE_TTL_SEC):
    """
    Ambil OHLC batch utk banyak tickers sekali tembak (cache + backoff).
    Return: dict {ticker: df_single}
    """
    key = (interval, period)
    if key in _cache and _within_ttl(_cache[key]["ts"], cache_ttl):
        big = _cache[key]["df"]
    else:
        # yfinance aman kalau list panjang tapi tetap bagi per chunk untuk amankan
        if isinstance(tickers, (set, tuple)):
            tickers = list(tickers)
        result_frames = []
        for i in range(0, len(tickers), BATCH_CHUNK):
            chunk = tickers[i:i+BATCH_CHUNK]
            df_chunk = _safe_download(chunk, interval, period)
            result_frames.append(df_chunk)
        # gabungkan: untuk multi-chunk, concat kolom
        if len(result_frames) == 1:
            big = result_frames[0]
        else:
            big = pd.concat(result_frames, axis=1)
        _cache[key] = {"ts": _now_utc(), "df": big}

    # Normalisasi menjadi dict per ticker
    out = {}
    # Struktur yfinance “group_by=ticker” → kolom top-level = ticker
    if isinstance(big.columns, pd.MultiIndex):
        top = sorted(set([c[0] for c in big.columns]))
        for t in top:
            sub = big[t].copy()
            # pastikan kolom standar
            if isinstance(sub.columns, pd.MultiIndex):
                sub.columns = sub.columns.get_level_values(0)
            out[t] = sub.dropna(how="all")
    else:
        # Kasus 1 ticker saja; kembalikan dengan key tickernya
        # Ticker tidak tersedia dari df -> caller harus isi manual
        out[tickers[0]] = big.dropna(how="all")
    return out