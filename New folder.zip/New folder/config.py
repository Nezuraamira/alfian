# =========[ CONFIG v6 ]==================================================

PAIRS = [
    "GC=F", "SI=F",
    "EURUSD=X", "USDJPY=X", "GBPUSD=X",
    "AUDUSD=X", "USDCAD=X", "USDCHF=X", "NZDUSD=X",
    "BTC-USD"
]

# Webhooks
DISCORD_WEBHOOK_SIGNALS = "https://canary.discord.com/api/webhooks/1404719357866676224/TqzFFrmkBxNMWyMLmYsujyvF8nxY-2-swSQt_wcYk_eiDMdFEP9NYN_K4QDe73yLz6zG"
DISCORD_WEBHOOK_NEWS    = "https://canary.discord.com/api/webhooks/1404719987230507019/acuYeXXzIR9zVPfcawA3df2wpzsX4-lRr_xAGx2hDtlIOlPx75JHvH1iViRV3lgiAHpw"
DISCORD_WEBHOOK_LOG     = "https://canary.discord.com/api/webhooks/1404720203358670981/hPa5ozapuhEcrak7i19kTm6Hx3AmH8-9LEA5mbr3c7fCMw9cTGTNnyYGpsm8cZ3lqSHp"

# Looping & heartbeat
HEARTBEAT_INTERVAL = 4 * 3600
WAIT_MINUTES       = 15
SUMMARY_EVERY_HOURS = 12       # summary period

# News (tetap jalan bila modul news ada)
NEWS_UPCOMING_ALERT_MIN = 90
NEWS_ALERT_IMPACTS = {"High", "Medium-High", "Medium"}
VOL_WARN_KEYWORDS = ["cpi","ppi","nfp","non-farm","fomc","rate decision"]

# Anti-delay signal (bar m15 harus fresh)
STRICT_BAR_CLOSE = True
STALE_MAX_SEC    = 90
BOUNDARY_BUFFER  = 4           # menit toleransi di boundary 15m

# ======== YFinance fetcher (anti rate-limit) ============================
# batch download + cache TTL
YF_PERIODS = {"1d": "180d", "60m": "60d", "15m": "7d"}
YF_TTL_SEC = 50                 # cache per (pair,interval)
YF_RETRY   = 4
YF_BACKOFF = 1.2                # detik
YF_SLEEP_BETWEEN_REQUEST = 0.8  # detik antar batch

# Files
SIGNAL_LOG  = "signals.json"
TRADES_FILE = "trades.json"     # paper-trade storage (auto winrate)
STATE_FILE  = "state.json"      # jadwal summary/heartbeat

# Risk model untuk TP/SL (pakai ATR H1)
SL_ATR_MULT = 1.5
TP_ATR_MULT = 2.5

# Filter volatilitas minimum (ATR% H1)
VOL_FLOOR_FX   = 0.050
VOL_FLOOR_FUT  = 0.100
VOL_FLOOR_CRYPTO = 0.500

# Request global
REQ_TIMEOUT = 3

# News feed flags (akan di-ignore jika modulnya tidak ada)
NEWS_FEEDS_ENABLED = {"dailyfx": True, "forexfactory": True, "fmp": False}