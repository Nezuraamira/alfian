import datetime as dt

def upcoming_high_impact(news_list, now_utc, ahead_min, impacts_set, vol_warn_keywords):
    alerts=[]; skipped=[]; warns=[]
    for ev in news_list:
        impact = (ev.get("impact") or "").title()
        t_raw = ev.get("time_utc")
        minutes=None
        try:
            t = dt.datetime.fromisoformat(str(t_raw).replace("Z",""))
            if t.tzinfo is None: t = t.replace(tzinfo=dt.timezone.utc)
            minutes = (t - now_utc).total_seconds()/60.0
        except Exception:
            minutes = None

        is_soon = (minutes is not None) and (0 <= minutes <= ahead_min)
        text = f"• {t_raw} | {impact} | {ev.get('currency','')} | {ev.get('title','')}"

        if impact in impacts_set and is_soon:
            alerts.append({"id":ev.get("id"), "text": text, "raw": ev})
            title = (ev.get("title") or "").lower()
            if any(k in title for k in (vol_warn_keywords or [])):
                warns.append(text + " — ⚠️ **Highly Volatile**")
        else:
            if impact not in impacts_set and is_soon:
                skipped.append(text + " — Skip (low/medium impact)")
    return alerts, skipped, warns

def news_bias(*args, **kwargs):
    return []

def recent_actuals(*args, **kwargs):
    return []
