import math, time, datetime as dt
import numpy as np, pandas as pd
import config as cfg
from fetcher import get_df

def ema(s, n):  return s.ewm(span=n, adjust=False).mean()
def rsi_wilder(close, n=14):
    delta = close.diff()
    up = delta.clip(lower=0); dn = -delta.clip(upper=0)
    au = up.ewm(alpha=1/n, adjust=False).mean()
    ad = dn.ewm(alpha=1/n, adjust=False).mean()
    rs = au / ad.replace(0, np.nan)
    out = 100 - 100/(1+rs)
    return out.fillna(50)
def macd(close):
    f = ema(close,12) - ema(close,26)
    s = f.ewm(span=9, adjust=False).mean()
    h = f - s
    return f, s, h
def atr(df, n=14):
    hi, lo, cl = df["High"], df["Low"], df["Close"]
    pc = cl.shift(1)
    tr = pd.concat([(hi-lo),(hi-pc).abs(),(lo-pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()

def _vol_floor(pair):
    if pair.endswith("-USD"):    return cfg.VOL_FLOOR_CRYPTO
    if pair.endswith("=F"):      return cfg.VOL_FLOOR_FUT
    return cfg.VOL_FLOOR_FX

def analyze_pair(pair: str, now_utc: dt.datetime):
    # ambil data cached (anti rate-limit)
    d1  = get_df(pair, "1d",  cfg.YF_PERIODS["1d"],  cfg.YF_TTL_SEC)
    h1  = get_df(pair, "60m", cfg.YF_PERIODS["60m"], cfg.YF_TTL_SEC)
    m15 = get_df(pair, "15m", cfg.YF_PERIODS["15m"], cfg.YF_TTL_SEC)

    if d1.empty or h1.empty or m15.empty:
        return None  # skip

    # pastikan UTC-aware (fetcher sudah melakukan, ini sekedar jaga-jaga)
    for df in (d1,h1,m15):
        idx = df.index
        if getattr(idx,'tz',None) is None: df.index = idx.tz_localize('UTC')

    # pastikan bar M15 terbaru (anti delay)
    expected_min = (now_utc.minute//15)*15
    expected_close = now_utc.replace(minute=expected_min, second=0, microsecond=0)
    last_ts = m15.index[-1].to_pydatetime()
    if last_ts.tzinfo is None: last_ts = last_ts.replace(tzinfo=dt.timezone.utc)
    latency_sec = max(0, (now_utc - last_ts).total_seconds())
    if cfg.STRICT_BAR_CLOSE and latency_sec > cfg.STALE_MAX_SEC:
        return None

    # indeks aman (hindari _get_value error)
    id1  = -1
    ih1  = -2 if len(h1)>1 else -1
    im15 = -1

    # D1
    ema200_d1 = ema(d1["Close"], 200)
    rsi_d1 = rsi_wilder(d1["Close"])
    price_d1 = float(d1["Close"].iat[id1])
    ema200_v = float(ema200_d1.iat[id1])
    rsi_d1_v = float(rsi_d1.iat[id1])
    trend_up = price_d1 > ema200_v
    trend_dn = price_d1 < ema200_v

    # H1
    rsi_h1  = rsi_wilder(h1["Close"])
    macd_l, macd_s, _ = macd(h1["Close"])
    atr_h1 = atr(h1)
    price_h1 = float(h1["Close"].iat[ih1])
    atr_h1_v = float(atr_h1.iat[ih1]) if not math.isnan(atr_h1.iat[ih1]) else 0.0
    atr_pct = (atr_h1_v / price_h1) * 100 if price_h1 else 0.0
    rsi_h1_v = float(rsi_h1.iat[ih1]); macd_v = float(macd_l.iat[ih1]); sig_v = float(macd_s.iat[ih1])

    # M15
    rsi_m15 = rsi_wilder(m15["Close"])
    ema20_m15 = ema(m15["Close"], 20)
    rsi_m15_v = float(rsi_m15.iat[im15])
    close_m15 = float(m15["Close"].iat[im15])
    ema20_v = float(ema20_m15.iat[im15])

    # trigger
    vol_ok = atr_pct >= _vol_floor(pair)
    up_mom = (macd_v > sig_v) and (rsi_h1_v > 50)
    dn_mom = (macd_v < sig_v) and (rsi_h1_v < 50)
    bull_tr = (rsi_m15_v > 35) and (close_m15 > ema20_v)
    bear_tr = (rsi_m15_v < 65) and (close_m15 < ema20_v)

    signal = None
    reasons = []
    if trend_up and up_mom and bull_tr and vol_ok:
        signal = "BUY"
        reasons = [
            f"Trend D1>EMA200 ({price_d1:.4f}>{ema200_v:.4f})",
            f"Momentum H1: MACD>Signal & RSI {rsi_h1_v:.1f}>50",
            f"Trigger M15: Close>EMA20 & RSI {rsi_m15_v:.1f}>35",
            f"ATR% {atr_pct:.3f} ≥ {_vol_floor(pair):.3f}"
        ]
    elif trend_dn and dn_mom and bear_tr and vol_ok:
        signal = "SELL"
        reasons = [
            f"Trend D1<EMA200 ({price_d1:.4f}<{ema200_v:.4f})",
            f"Momentum H1: MACD<Signal & RSI {rsi_h1_v:.1f}<50",
            f"Trigger M15: Close<EMA20 & RSI {rsi_m15_v:.1f}<65",
            f"ATR% {atr_pct:.3f} ≥ {_vol_floor(pair):.3f}"
        ]

    if not signal:
        return None

    # TP/SL berdasar ATR H1
    sl_mult, tp_mult = cfg.SL_ATR_MULT, cfg.TP_ATR_MULT
    if signal == "BUY":
        sl = price_h1 - sl_mult * atr_h1_v
        tp = price_h1 + tp_mult * atr_h1_v
    else:
        sl = price_h1 + sl_mult * atr_h1_v
        tp = price_h1 - tp_mult * atr_h1_v

    # Confidence score (0..100)
    score = 0.0
    score += 25.0 if (trend_up or trend_dn) else 0.0
    if up_mom or dn_mom: score += 25.0
    if bull_tr or bear_tr: score += 25.0
    score += 25.0 * min(1.0, max(0.0, atr_pct / max(1e-9, _vol_floor(pair))))
    conf = round(min(100.0, score), 1)

    # output ringkas; alasan tetap jelas
    latency_str = f"{int(latency_sec)}s" if latency_sec < 60 else f"{latency_sec/60:.1f}m"
    text = (
        f"🟢 *{pair} | {signal}*\n"
        f"• Confidence: *{conf:.1f}%*  ⏱ Latency≈ {latency_str}\n"
        f"• D1 RSI: {rsi_d1_v:.1f} | EMA200: {ema200_v:.4f}\n"
        f"• H1 RSI: {rsi_h1_v:.1f} | MACD: {macd_v:.5f}/{sig_v:.5f} | ATR%: {atr_pct:.3f}\n"
        f"• M15 RSI: {rsi_m15_v:.1f} | Close/EMA20: {close_m15:.5f}/{ema20_v:.5f}\n"
        f"• Entry≈ {price_h1:.5f} | SL≈ {sl:.5f} | TP≈ {tp:.5f}\n"
        f"• Alasan: " + "; ".join(reasons)
    )# analyzer.py
import time
import math
import datetime as dt
import numpy as np
import pandas as pd

from marketdata import fetch_batch  # <-- gunakan batch
import config as cfg

def rsi_wilder(close: pd.Series, period=14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)

def ema(series: pd.Series, period=20) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()

def macd(close: pd.Series):
    ema12 = ema(close, 12); ema26 = ema(close, 26)
    macd_line = ema12 - ema26
    signal = macd_line.ewm(span=9, adjust=False).mean()
    hist = macd_line - signal
    return macd_line, signal, hist

def atr(df: pd.DataFrame, period=14) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/period, adjust=False).mean()

def signal_confidence(trend_up, trend_dn, rsi_h1_v, macd_v, sig_v, atr_pct, vol_floor, rsi_m15_v, close_m15, ema20_v):
    score = 0.0
    score += 25.0 if (trend_up or trend_dn) else 0.0
    if (macd_v > sig_v and rsi_h1_v > 50) or (macd_v < sig_v and rsi_h1_v < 50):
        score += 25.0
    if (rsi_m15_v > 35 and close_m15 > ema20_v) or (rsi_m15_v < 65 and close_m15 < ema20_v):
        score += 25.0
    score += 25.0 * min(1.0, max(0.0, (atr_pct / max(1e-9, vol_floor))))
    return round(min(100.0, score), 1)

def _prep_idx_utc(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    if df.index.tz is None:
        df.index = df.index.tz_localize('UTC')
    else:
        df.index = df.index.tz_convert('UTC')
    return df

def analyze_all_pairs(pairs):
    """
    Download batch per timeframe → analisa per pair.
    Return: list of (pair, ok, msg)
    """
    # 1) Ambil semua data sekali tembak per timeframe
    d1_all  = fetch_batch(pairs, "1d",  "180d")
    h1_all  = fetch_batch(pairs, "60m", "60d")
    m15_all = fetch_batch(pairs, "15m", "7d")

    results = []
    for pair in pairs:
        try:
            d1  = _prep_idx_utc(d1_all.get(pair, pd.DataFrame()))
            h1  = _prep_idx_utc(h1_all.get(pair, pd.DataFrame()))
            m15 = _prep_idx_utc(m15_all.get(pair, pd.DataFrame()))

            if d1.empty or h1.empty or m15.empty or "Close" not in d1 or "Close" not in h1 or "Close" not in m15:
                results.append((pair, False, "no-signal"))
                continue

            # Freshness guard M15 (anti telat)
            now_utc = dt.datetime.now(dt.timezone.utc).replace(second=0, microsecond=0)
            last_m15 = m15.index[-1].to_pydatetime()
            if last_m15.tzinfo is None:
                last_m15 = last_m15.replace(tzinfo=dt.timezone.utc)
            latency_sec = max(0, (now_utc - last_m15).total_seconds())
            if getattr(cfg, "STRICT_BAR_CLOSE", True) and latency_sec > getattr(cfg, "STALE_MAX_SEC", 90):
                results.append((pair, False, "no-signal"))
                continue

            # Indikator
            ema200_d1 = ema(d1["Close"], 200)
            rsi_d1    = rsi_wilder(d1["Close"])
            price_d1  = float(d1["Close"].iat[-1])
            ema200_v  = float(ema200_d1.iat[-1])
            rsi_d1_v  = float(rsi_d1.iat[-1])
            trend_up  = price_d1 > ema200_v
            trend_dn  = price_d1 < ema200_v

            rsi_h1  = rsi_wilder(h1["Close"])
            macd_l, macd_s, _ = macd(h1["Close"])
            atr_h1  = atr(h1)
            price_h1 = float(h1["Close"].iat[-1])
            atr_h1_v = float(atr_h1.iat[-1]) if not np.isnan(atr_h1.iat[-1]) else 0.0
            atr_pct  = (atr_h1_v / price_h1) * 100 if price_h1 else 0.0

            if pair.endswith("-USD"):
                vol_floor = 0.5
            elif pair.endswith("=F"):
                vol_floor = 0.10
            else:
                vol_floor = 0.05

            rsi_h1_v = float(rsi_h1.iat[-1])
            macd_v   = float(macd_l.iat[-1])
            sig_v    = float(macd_s.iat[-1])
            momentum_up   = (macd_v > sig_v) and (rsi_h1_v > 50)
            momentum_down = (macd_v < sig_v) and (rsi_h1_v < 50)
            volatility_ok = atr_pct >= vol_floor

            rsi_m15   = rsi_wilder(m15["Close"])
            ema20_m15 = ema(m15["Close"], 20)
            rsi_m15_v = float(rsi_m15.iat[-1])
            close_m15 = float(m15["Close"].iat[-1])
            ema20_v   = float(ema20_m15.iat[-1])

            bull_trigger = (rsi_m15_v > 35) and (close_m15 > ema20_v)
            bear_trigger = (rsi_m15_v < 65) and (close_m15 < ema20_v)

            signal = None; reasons = []
            if trend_up and momentum_up and bull_trigger and volatility_ok:
                signal = "BUY"
                reasons = [
                    f"Trend D1>EMA200 ({price_d1:.4f}>{ema200_v:.4f})",
                    f"Mom H1: MACD>Signal & RSI {rsi_h1_v:.1f}>50",
                    f"Trig M15: Close>EMA20 & RSI {rsi_m15_v:.1f}>35",
                    f"ATR% {atr_pct:.3f} ≥ {vol_floor:.3f}"
                ]
            elif trend_dn and momentum_down and bear_trigger and volatility_ok:
                signal = "SELL"
                reasons = [
                    f"Trend D1<EMA200 ({price_d1:.4f}<{ema200_v:.4f})",
                    f"Mom H1: MACD<Signal & RSI {rsi_h1_v:.1f}<50",
                    f"Trig M15: Close<EMA20 & RSI {rsi_m15_v:.1f}<65",
                    f"ATR% {atr_pct:.3f} ≥ {vol_floor:.3f}"
                ]

            if not signal:
                results.append((pair, False, "no-signal"))
                continue

            sl_mult, tp_mult = (1.5, 2.5)
            if signal == "BUY":
                sl = price_h1 - sl_mult * atr_h1_v
                tp = price_h1 + tp_mult * atr_h1_v
            else:
                sl = price_h1 + sl_mult * atr_h1_v
                tp = price_h1 - tp_mult * atr_h1_v

            conf = signal_confidence(trend_up, trend_dn, rsi_h1_v, macd_v, sig_v, atr_pct, vol_floor, rsi_m15_v, close_m15, ema20_v)
            latency_str = f"{latency_sec/60:.1f}m" if latency_sec >= 60 else f"{int(latency_sec)}s"

            msg = (
                f"🟢 *{pair}* | *{signal}*\n"
                f"• Confidence: *{conf:.1f}%* | ⏱ Latency≈ {latency_str}\n"
                f"• D1 RSI: {rsi_d1_v:.1f} | EMA200: {ema200_v:.4f}\n"
                f"• H1 RSI: {rsi_h1_v:.1f} | MACD: {macd_v:.5f}/{sig_v:.5f} | ATR%: {atr_pct:.3f}\n"
                f"• M15 RSI: {rsi_m15_v:.1f} | Close/EMA20: {close_m15:.5f}/{ema20_v:.5f}\n"
                f"• Entry≈ {price_h1:.5f} | SL≈ {sl:.5f} | TP≈ {tp:.5f}\n"
                f"• Alasan: " + "; ".join(reasons)
            )
            results.append((pair, True, msg))
        except Exception as e:
            results.append((pair, False, f"error: {e}"))
    return results
    return {
        "pair": pair, "side": signal, "text": text,
        "entry": price_h1, "sl": sl, "tp": tp,
        "conf": conf, "latency_sec": latency_sec
    }