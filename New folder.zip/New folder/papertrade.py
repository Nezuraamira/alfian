import json, os, time, datetime as dt
import yfinance as yf

def _load(path):
    if not os.path.exists(path): return {"open": [], "closed": []}
    try:
        with open(path, "r") as f: return json.load(f)
    except Exception: return {"open": [], "closed": []}

def _save(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w") as f: json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)

def add_trade(path, pair, side, entry, sl, tp, confidence):
    book = _load(path)
    book["open"].append({
        "ts": time.time(),
        "pair": pair, "side": side,
        "entry": float(entry), "sl": float(sl), "tp": float(tp),
        "confidence": float(confidence)
    })
    _save(path, book)

def _recent_high_low(ticker, since_ts):
    for interval in ("1m","5m"):
        try:
            df = yf.download(ticker, period="2d", interval=interval, auto_adjust=True, progress=False, threads=False)
            if df is None or df.empty: continue
            if df.index.tz is None: df.index = df.index.tz_localize("UTC")
            else: df.index = df.index.tz_convert("UTC")
            df = df[df.index >= dt.datetime.utcfromtimestamp(since_ts).replace(tzinfo=dt.timezone.utc)]
            if df.empty: continue
            return float(df["High"].max()), float(df["Low"].min())
        except Exception:
            continue
    return None, None

def update(path):
    book = _load(path)
    still_open = []
    for tr in book["open"]:
        hi, lo = _recent_high_low(tr["pair"], tr["ts"])
        if hi is None:
            still_open.append(tr); continue
        hit_tp = (hi >= tr["tp"]) if tr["side"]=="BUY" else (lo <= tr["tp"])
        hit_sl = (lo <= tr["sl"]) if tr["side"]=="BUY" else (hi >= tr["sl"])
        if hit_tp or hit_sl:
            tr["close_ts"] = time.time()
            tr["result"] = "win" if hit_tp else "loss"
            book["closed"].append(tr)
        else:
            still_open.append(tr)
    book["open"] = still_open
    _save(path, book)

def winrate_report(path):
    book = _load(path)
    now = time.time()
    def _slice(hours):
        cut = now - hours*3600
        return [t for t in book["closed"] if t.get("close_ts",0) >= cut]
    def _wr(items):
        if not items: return (0,0,0.0)
        n = len(items); w = sum(1 for x in items if x.get("result")=="win")
        return (n, w, (w/n)*100.0)
    h12 = _wr(_slice(12)); d1 = _wr(_slice(24)); w1 = _wr(_slice(24*7))
    lines = [
        "📊 **Periodic Summary**",
        f"• 12h → Trades: {h12[0]} | Win: {h12[1]} | Win-rate: **{h12[2]:.1f}%**",
        f"• 1d  → Trades: {d1[0]}  | Win: {d1[1]}  | Win-rate: **{d1[2]:.1f}%**",
        f"• 1w  → Trades: {w1[0]}  | Win: {w1[1]}  | Win-rate: **{w1[2]:.1f}%**",
    ]
    return "\n".join(lines)
