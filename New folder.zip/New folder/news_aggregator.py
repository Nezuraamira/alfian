import datetime as dt
import requests
from notifier import send_log
import config as cfg

def _norm_time(s):
    if not s: return ""
    if isinstance(s, (int,float)):
        return dt.datetime.utcfromtimestamp(s).isoformat()
    return str(s)

def _dedup(items):
    seen=set(); out=[]
    for ev in items:
        key = (ev.get("time_utc",""), ev.get("currency",""), ev.get("title",""))
        if key in seen: continue
        seen.add(key); out.append(ev)
    return out

def get_news():
    """Return (events, source_note, note). Toleran; tidak crash bila feed fail."""
    events=[]; srcs=[]; note=""
    s = requests.Session()

    # FMP (opsional)
    if cfg.NEWS_FEEDS_ENABLED.get("fmp") and cfg.FMP_API_KEY:
        try:
            from fmp import fetch as fmp_fetch
            ev = fmp_fetch()
            if ev: events += ev; srcs.append("fmp")
        except Exception as e:
            send_log(f"[NEWS] fmp fail: {e}")

    # DailyFX
    if cfg.NEWS_FEEDS_ENABLED.get("dailyfx"):
        try:
            from dailyfx import fetch as dfx_fetch
            ev = dfx_fetch(s)
            if ev: events += ev; srcs.append("dailyfx")
        except Exception as e:
            send_log(f"[NEWS] dailyfx fail: {e}")

    # ForexFactory
    if cfg.NEWS_FEEDS_ENABLED.get("forexfactory"):
        try:
            from forexfactory import fetch_this_week
            ev = fetch_this_week(s)
            if ev: events += ev; srcs.append("forexfactory")
        except Exception as e:
            send_log(f"[NEWS] forexfactory fail: {e}")

    events = [{
        "id": e.get("id"),
        "title": e.get("title",""),
        "currency": e.get("currency",""),
        "impact": e.get("impact","Medium"),
        "time_utc": _norm_time(e.get("time_utc")),
        "source": e.get("source","")
    } for e in (events or [])]

    events = _dedup(events)
    source_note = ",".join(srcs) if srcs else "none"
    if not events:
        note = "empty"
    return events, source_note, note
