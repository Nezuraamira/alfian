import json, os, time, datetime as dt
from typing import List, Dict

def _load(path): 
    if not os.path.exists(path): return []
    with open(path,"r") as f: 
        try: return json.load(f)
        except: return []

def _save(path, data):
    tmp = path + ".tmp"
    with open(tmp,"w") as f: json.dump(data, f, indent=2)
    os.replace(tmp, path)

def record_signal(path, pair, side, entry, sl, tp, ts_utc: float):
    data = _load(path)
    data.append({
        "pair": pair, "side": side,
        "entry": entry, "sl": sl, "tp": tp,
        "ts": ts_utc, "status": "open"
    })
    _save(path, data)

def settle_by_price(path, pair, last_price):
    """Jika ada trade open pada pair ini, cek apakah TP/SL tersentuh."""
    data = _load(path); changed=False
    for t in data:
        if t.get("status")=="open" and t.get("pair")==pair:
            side = t["side"]; tp=t["tp"]; sl=t["sl"]
            if side=="BUY":
                if last_price >= tp: t["status"]="win"; changed=True
                elif last_price <= sl: t["status"]="loss"; changed=True
            else:
                if last_price <= tp: t["status"]="win"; changed=True
                elif last_price >= sl: t["status"]="loss"; changed=True
    if changed: _save(path, data)

def _range_cutoff(hours: int):
    return time.time() - hours*3600

def summary(path, hours: int):
    data = _load(path)
    cutoff = _range_cutoff(hours)
    trades = [t for t in data if t.get("ts",0)>=cutoff]
    total = len(trades)
    won = sum(1 for t in trades if t.get("status")=="win")
    lost = sum(1 for t in trades if t.get("status")=="loss")
    open_ = total - won - lost
    winrate = (won/total*100) if total>0 else 0.0
    return {"total": total, "won": won, "lost": lost, "open": open_, "winrate": round(winrate,1)}