import requests, datetime as dt
import config as cfg

def fetch():
    if not cfg.FMP_API_KEY:
        raise RuntimeError("No FMP key")
    try:
        today = dt.date.today()
        d1 = today - dt.timedelta(days=1)
        d2 = today + dt.timedelta(days=3)
        url = f"{cfg.FMP_BASE}?from={d1}&to={d2}&apikey={cfg.FMP_API_KEY}"
        r = requests.get(url, timeout=cfg.REQ_TIMEOUT, proxies=cfg.PROXIES)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        raise RuntimeError(e)

    out=[]
    for ev in (data or []):
        try:
            title = ev.get("event") or ""
            curr  = (ev.get("country") or "").upper()
            impact= ev.get("impact") or "Medium"
            t = ev.get("date") or ev.get("timestamp")
            out.append({
                "id": f"fmp-{t}-{title}",
                "title": title, "currency": curr, "impact": impact,
                "time_utc": t, "source": "fmp"
            })
        except Exception:
            continue
    return out
