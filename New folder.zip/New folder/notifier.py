import json, requests, time
import config as cfg

def _post(url, content):
    try:
        requests.post(url, json={"content": content}, timeout=cfg.REQ_TIMEOUT)
    except Exception:
        pass

def send_signal(text: str):
    _post(cfg.DISCORD_WEBHOOK_SIGNALS, text)

def send_log(text: str):
    _post(cfg.DISCORD_WEBHOOK_LOG, text)

def send_heartbeat():
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    send_log(f"✅ Bot masih aktif — {ts}")

def send_summary(stats12, stats24, stats168):
    def line(s, lbl):
        return f"{lbl}** — Trades: {s['total']} | Win: {s['won']} | Loss: {s['lost']} | Open: {s['open']} | WinRate: *{s['winrate']}%*"
    msg = "📊 *Periodic Summary*\n" + "\n".join([
        line(stats12,"12h"),
        line(stats24,"1d"),
        line(stats168,"1w"),
    ])
    send_log(msg)

# News (opsional – gunakan modul news kamu)
def send_news_alert(text: str):
    _post(cfg.DISCORD_WEBHOOK_NEWS, text)