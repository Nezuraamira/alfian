import time, threading
from typing import Dict, Tuple, List
import pandas as pd
import yfinance as yf

# cache sederhana: {(symbol, interval): (timestamp, df)}
_cache: Dict[Tuple[str, str], Tuple[float, pd.DataFrame]] = {}
_cache_lock = threading.Lock()

def _sanitize_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df

def _as_utc_index(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty: return df
    idx = df.index
    if getattr(idx, "tz", None) is None:
        df.index = idx.tz_localize("UTC")
    else:
        df.index = idx.tz_convert("UTC")
    return df

def _download_batch(symbols: List[str], interval: str, period: str) -> Dict[str, pd.DataFrame]:
    # yfinance batch
    data = yf.download(
        tickers=" ".join(symbols),
        interval=interval,
        period=period,
        auto_adjust=True,
        progress=False,
        threads=False,
        group_by="ticker",
    )
    out: Dict[str, pd.DataFrame] = {}
    if isinstance(data, pd.DataFrame) and not data.empty and isinstance(data.columns, pd.MultiIndex):
        # format multi-ticker
        for sym in symbols:
            if sym in data.columns.levels[0]:
                df = data[sym].dropna(how="all")
                df = _sanitize_columns(df)
                df = _as_utc_index(df)
                out[sym] = df
    else:
        # single-ticker fallback (yfinance kadang lempar df tunggal)
        for sym in symbols:
            df = yf.download(sym, interval=interval, period=period, auto_adjust=True,
                             progress=False, threads=False)
            df = _sanitize_columns(df)
            df = _as_utc_index(df)
            out[sym] = df
    return out

def prefetch(symbols: List[str], interval: str, period: str, ttl_sec: int,
             retry: int, backoff: float, sleep_between: float):
    now = time.time()
    # Filter yang belum ada/expired
    need = []
    with _cache_lock:
        for s in symbols:
            key = (s, interval)
            if key not in _cache or now - _cache[key][0] > ttl_sec:
                need.append(s)
    if not need:
        return

    # pecah batch 4 ticker sekali (aman untuk YF)
    BATCH = 4
    for i in range(0, len(need), BATCH):
        chunk = need[i:i+BATCH]
        last_err = None
        for attempt in range(retry):
            try:
                got = _download_batch(chunk, interval, period)
                with _cache_lock:
                    for sym, df in got.items():
                        _cache[(sym, interval)] = (time.time(), df)
                break
            except Exception as e:
                last_err = e
                time.sleep(backoff*(attempt+1))
        if last_err:
            # simpan kosong supaya tidak spin
            with _cache_lock:
                for sym in chunk:
                    if (sym, interval) not in _cache:
                        _cache[(sym, interval)] = (time.time(), pd.DataFrame())
        time.sleep(sleep_between)

def get_df(symbol: str, interval: str, period: str, ttl_sec: int) -> pd.DataFrame:
    now = time.time()
    key = (symbol, interval)
    with _cache_lock:
        if key in _cache and now - _cache[key][0] <= ttl_sec:
            return _cache[key][1].copy()
    # belum ada → unduh single
    df = yf.download(symbol, interval=interval, period=period,
                     auto_adjust=True, progress=False, threads=False)
    df = _sanitize_columns(df)
    df = _as_utc_index(df)
    with _cache_lock:
        _cache[key] = (time.time(), df)
    return df.copy()