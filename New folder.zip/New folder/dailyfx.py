import requests, datetime as dt
import config as cfg

DFX_URL = "https://calendar.dailyfx.com/v1/events"

def _imp(n):
    # DailyFX: 1=low, 2=med, 3=high (umum)
    try:
        v = int(n or 0)
    except Exception:
        v = 0
    return {1:"Low", 2:"Medium", 3:"High"}.get(v, "Low")

def fetch(session=None):
    s = session or requests.Session()
    try:
        r = s.get(cfg.DAILYFX_URL or DFX_URL, timeout=cfg.REQ_TIMEOUT, proxies=cfg.PROXIES)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        raise RuntimeError(e)

    out=[]
    for ev in (data or []):
        try:
            t = ev.get("date") or ev.get("datetime") or ev.get("time") or ev.get("timestamp")
            if isinstance(t, (int,float)):
                t = dt.datetime.utcfromtimestamp(t).isoformat()
            title = ev.get("title") or ev.get("event") or ""
            curr  = ev.get("currency") or ev.get("ccy") or ""
            impact= _imp(ev.get("importance") or ev.get("impact") or 0)
            out.append({
                "id": f"dfx-{t}-{title}",
                "title": title, "currency": curr, "impact": impact,
                "time_utc": t, "source": "dailyfx"
            })
        except Exception:
            continue
    return out
