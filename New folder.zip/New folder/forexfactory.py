import requests
from bs4 import BeautifulSoup
import config as cfg

FF_URL = "https://www.forexfactory.com/calendar?week=this"

def _txt(el):
    return (el.get_text(" ", strip=True) if el else "").strip()

def fetch_this_week(session=None):
    s = session or requests.Session()
    try:
        r = s.get(
            FF_URL,
            timeout=cfg.REQ_TIMEOUT,
            verify=cfg.FF_VERIFY_SSL,
            proxies=cfg.PROXIES,
            headers={"User-Agent":"Mozilla/5.0"}
        )
        r.raise_for_status()
    except Exception as e:
        raise RuntimeError(e)

    try:
        soup = BeautifulSoup(r.text, "lxml")
    except Exception:
        soup = BeautifulSoup(r.text, "html.parser")

    out = []
    rows = soup.select("tr.calendar__row") or soup.find_all("tr")
    for tr in rows:
        try:
            impact = ""
            imp_cell = tr.select_one("[data-impact]")
            if imp_cell:
                v = imp_cell.get("data-impact","").lower()
                if "high" in v or "3" in v: impact="High"
                elif "medium" in v or "2" in v: impact="Medium"
                elif "low" in v or "1" in v: impact="Low"
            title = _txt(tr.select_one(".calendar__event-title")) or _txt(tr.select_one(".calendar__event"))
            curr  = _txt(tr.select_one(".calendar__currency"))
            time_cell = _txt(tr.select_one(".calendar__time"))
            if not title or not curr: continue
            out.append({
                "id": f"ff-{time_cell}-{title}",
                "title": title, "currency": curr, "impact": impact or "Medium",
                "time_utc": time_cell, "source": "forexfactory"
            })
        except Exception:
            continue
    return out
