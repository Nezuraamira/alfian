import time
import datetime as dt

import config as cfg
from fetcher import prefetch, get_df
from analyzer import analyze_pair
from notifier import send_signal, send_log, send_heartbeat, send_summary, send_news_alert
import stats as ST


def _now_utc() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _maybe_news(now_utc: dt.datetime):
    """Panggil news aggregator kalau ada; aman dari crash."""
    try:
        import news_aggregator as NA
        alerts, skipped, warns = NA.get_news(now_utc, cfg)
        for a in alerts:
            send_news_alert(a)
        # kalau mau, bisa kirim skipped/warns ke log:
        # if skipped: send_log(f"[NEWS] skipped: {len(skipped)}")
        # if warns:   send_log(f"[NEWS] warns: {len(warns)}")
    except Exception as e:
        # jangan bikin bot mati karena news
        send_log(f"[NEWS] handler error: {e}")


def _sleep_align(minutes: int):
    """Tidur hingga selaras ke kelipatan menit (mengurangi delay sinyal)."""
    now = _now_utc().replace(second=0, microsecond=0)
    total = minutes * 60
    rem = total - (int(now.timestamp()) % total)
    time.sleep(rem if 0 < rem <= total else total)


def main():
    last_hb = 0.0
    last_summary = 0.0

    while True:
        start = time.time()
        now = _now_utc()

        # HEARTBEAT
        if start - last_hb >= cfg.HEARTBEAT_INTERVAL:
            try:
                send_heartbeat()
            finally:
                last_hb = start

        # PREFETCH anti rate-limit (batch sekali per TF)
        try:
            prefetch(cfg.PAIRS, "1d",  cfg.YF_PERIODS["1d"],
                     cfg.YF_TTL_SEC, cfg.YF_RETRY, cfg.YF_BACKOFF, cfg.YF_SLEEP_BETWEEN_REQUEST)
            prefetch(cfg.PAIRS, "60m", cfg.YF_PERIODS["60m"],
                     cfg.YF_TTL_SEC, cfg.YF_RETRY, cfg.YF_BACKOFF, cfg.YF_SLEEP_BETWEEN_REQUEST)
            prefetch(cfg.PAIRS, "15m", cfg.YF_PERIODS["15m"],
                     cfg.YF_TTL_SEC, cfg.YF_RETRY, cfg.YF_BACKOFF, cfg.YF_SLEEP_BETWEEN_REQUEST)
        except Exception as e:
            send_log(f"[PREFETCH] error: {e}")

        # NEWS
        _maybe_news(now)

        # ANALYZE & paper-trade settle
        for p in cfg.PAIRS:
            try:
                sig = analyze_pair(p, now)
                # settle posisi lama di harga H1 terakhir
                try:
                    h1 = get_df(p, "60m", cfg.YF_PERIODS["60m"], cfg.YF_TTL_SEC)
                    last_price = float(h1["Close"].iat[-1]) if not h1.empty else None
                    if last_price is not None:
                        ST.settle_by_price(cfg.TRADES_FILE, p, last_price)
                except Exception:
                    pass

                if not sig:
                    continue

                # kirim sinyal & catat trade
                send_signal(sig["text"])
                ST.record_signal(
                    cfg.TRADES_FILE,
                    sig["pair"], sig["side"],
                    sig["entry"], sig["sl"], sig["tp"],
                    time.time()
                )
            except Exception as e:
                send_log(f"❌ {p}: {e}")

        # SUMMARY ke logger (12h/24h/7d)
        if time.time() - last_summary >= cfg.SUMMARY_EVERY_HOURS * 3600:
            try:
                s12  = ST.summary(cfg.TRADES_FILE, 12)
                s24  = ST.summary(cfg.TRADES_FILE, 24)
                s168 = ST.summary(cfg.TRADES_FILE, 24 * 7)
                send_summary(s12, s24, s168)
            except Exception as e:
                send_log(f"[SUMMARY] error: {e}")
            last_summary = time.time()

        # tunggu selaras ke kelipatan WAIT_MINUTES (kurangi lag sinyal M15)
        _sleep_align(cfg.WAIT_MINUTES)


if _name_ == "_main_":
    main()