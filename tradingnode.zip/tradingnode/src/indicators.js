export function ema(values, period){
  if (!values.length) return [];
  const k = 2/(period+1);
  const out=[]; let prev=values[0];
  for (let i=0;i<values.length;i++){
    const v=values[i];
    prev = i===0 ? v : v*k + prev*(1-k);
    out.push(prev);
  }
  return out;
}
export function rsi(values, period=14){
  const out=[]; let g=0,l=0;
  for (let i=1;i<values.length;i++){
    const ch=values[i]-values[i-1];
    g=(g*(period-1)+Math.max(ch,0))/period;
    l=(l*(period-1)+Math.max(-ch,0))/period;
    const rs = l===0 ? 100 : g/l;
    out.push(100 - (100/(1+rs)));
  }
  out.unshift(50); return out;
}
export function macd(values, fast=12, slow=26, signal=9){
  const f=ema(values,fast), s=ema(values,slow);
  const m=values.map((_,i)=>f[i]-s[i]);
  const sig=ema(m,signal);
  const hist=m.map((v,i)=>v-sig[i]);
  return { macdLine:m, signalLine:sig, hist };
}
export function atr(candles, period=14){
  const trs=[];
  for (let i=0;i<candles.length;i++){
    if (i===0){ trs.push(candles[i].h-candles[i].l); continue; }
    const h=candles[i].h, l=candles[i].l, pc=candles[i-1].c;
    trs.push(Math.max(h-l, Math.abs(h-pc), Math.abs(l-pc)));
  }
  const out=[]; let sum=0;
  for (let i=0;i<trs.length;i++){
    sum+=trs[i];
    if (i<period) out.push(sum/(i+1)); else { sum-=trs[i-period]; out.push(sum/period); }
  }
  return out;
}
