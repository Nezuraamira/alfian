import * as undici from 'undici';
if (typeof globalThis.File === 'undefined' && undici.File) globalThis.File = undici.File;
if (typeof globalThis.FormData === 'undefined' && undici.FormData) globalThis.FormData = undici.FormData;
if (typeof globalThis.Blob === 'undefined' && undici.Blob) globalThis.Blob = undici.Blob;
