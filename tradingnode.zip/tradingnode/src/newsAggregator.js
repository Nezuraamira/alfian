import config from "./config.js";
import { fetchDailyfx } from "./fetch/dailyfx.js";
import { fetchForexfactory } from "./fetch/forexfactory.js";
import { fetchFmp } from "./fetch/fmp.js";

export async function fetchAllNews(){
  let events = [];
  if (config.NEWS_FEEDS_ENABLED?.dailyfx) {
    events = await fetchDailyfx();
    if (events.length) return events;
  }
  if (config.NEWS_FEEDS_ENABLED?.forexfactory) {
    events = await fetchForexfactory();
    if (events.length) return events;
  }
  if (config.NEWS_FEEDS_ENABLED?.fmp ?? true) {
    events = await fetchFmp(3);
  }
  return events;
}
