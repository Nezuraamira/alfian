export const DISCORD_WEBHOOK_SIGNALS = "https://canary.discord.com/api/webhooks/1404719357866676224/TqzFFrmkBxNMWyMLmYsujyvF8nxY-2-swSQt_wcYk_eiDMdFEP9NYN_K4QDe73yLz6zG";
export const DISCORD_WEBHOOK_NEWS    = "https://canary.discord.com/api/webhooks/1404719987230507019/acuYeXXzIR9zVPfcawA3df2wpzsX4-lRr_xAGx2hDtlIOlPx75JHvH1iViRV3lgiAHpw";
export const DISCORD_WEBHOOK_LOG     = "https://canary.discord.com/api/webhooks/1404720203358670981/hPa5ozapuhEcrak7i19kTm6Hx3AmH8-9LEA5mbr3c7fCMw9cTGTNnyYGpsm8cZ3lqSHp";
