import './shims.js';
import 'dotenv/config.js';
import config from "./config.js";
import { analyzePair } from "./analyzer.js";
import { sendSignal, sendLog, sendNews } from "./notifier.js";
import { saveTrade } from "./papertrade.js";
import { summary } from "./stats.js";
import { fetchAllNews } from "./newsAggregator.js";

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

// Normalisasi PAIRS (array / string / list Python) → selalu array valid
function normalizePairs(input){
  if (Array.isArray(input)) return input;
  if (typeof input === "string"){
    let s = input.trim();
    if (s.startsWith("[") && s.endsWith("]")){
      try {
        const arr = JSON.parse(s.replace(/'/g,'"'));
        if (Array.isArray(arr)) return arr.map(x=>String(x).trim()).filter(Boolean);
      } catch { s = s.slice(1,-1); }
    }
    return s.split(/[,;\s]+/).map(x=>x.replace(/^['"]|['"]$/g,'').trim()).filter(Boolean);
  }
  return [];
}
const PAIRS = normalizePairs(config.PAIRS);

async function heartbeatLoop(){
  let last = 0, lastSummary = 0;
  while (true){
    const now = Date.now();
    if (now - last > config.HEARTBEAT_INTERVAL*1000){
      await sendLog(`✅ Heartbeat ok @ ${new Date().toISOString()}`);
      last = now;
    }
    if (now - lastSummary > config.PERIODIC_SUMMARY_HOURS*3600*1000){
      const s = summary(config.PERIODIC_SUMMARY_HOURS);
      await sendLog(`📊 Summary ${config.PERIODIC_SUMMARY_HOURS}h — total:${s.total} win:${s.win} loss:${s.loss} be:${s.be} | WR:${s.wr}%`);
      lastSummary = now;
    }
    await sleep(5000);
  }
}

function formatNews(lines){
  return lines.map(e=>{
    const parts = [];
    if (e.timestamp) parts.push(`🕒 ${e.timestamp}`);
    parts.push(`**${e.title}**`);
    if (e.impact) parts.push(`(${e.impact})`);
    const afp = [];
    if (e.actual!=null && e.actual!=="") afp.push(`A: ${e.actual}`);
    if (e.forecast!=null && e.forecast!=="") afp.push(`F: ${e.forecast}`);
    if (e.previous!=null && e.previous!=="") afp.push(`P: ${e.previous}`);
    if (afp.length) parts.push(afp.join(" | "));
    return `• [${e.source}] ` + parts.join(" — ");
  }).join("\n");
}

async function mainLoop(){
  while(true){
    console.log(`[LOOP] ${new Date().toISOString()} analyzing ${PAIRS.length} pairs...`);

    // NEWS (opsional)
    try{
      const news = await fetchAllNews();
      if (news.length){
        console.log(`[NEWS] got ${news.length} items`);
        await sendNews(formatNews(news.slice(0, 8)));
      } else {
        console.warn("[NEWS] no items (blocked/limited?)");
      }
    }catch(e){
      console.warn("[NEWS] skipped:", e?.message || e);
    }

    // ANALYZE
    for (const p of PAIRS){
      const res = await analyzePair(p);
      if (!res.ok){
        console.log(`[ANALYZE] ${p || '-'} → ${res.reason}`);
        continue;
      }
      console.log(`[SIGNAL] ${p} ${res.side} entry=${res.entry.toFixed(5)} sl=${res.sl.toFixed(5)} tp=${res.tp.toFixed(5)} conf=${res.confidence}%`);
      await sendSignal(`📈 **${p}** ${res.side}\nEntry: ${res.entry.toFixed(5)}\nSL: ${res.sl.toFixed(5)}\nTP: ${res.tp.toFixed(5)}\nConf: ${res.confidence}%`);
      saveTrade(res);
    }

    const jitter = Math.floor(Math.random()*(60-20+1))+20;
    const wait = (config.WAIT_MINUTES*60 + jitter)*1000;
    console.log(`[SLEEP] ${Math.round(wait/1000)}s`);
    await sleep(wait);
  }
}

console.log("Bot start (pairs + news; summary -> LOG)");
heartbeatLoop();
mainLoop();
