import yahooFinance from "yahoo-finance2";

// tentukan periode epoch detik
function computePeriod(interval) {
  let days;
  if (interval === "1d") days = 365;           // untuk EMA200
  else if (interval === "1h") days = 60;       // 60 hari
  else if (interval === "15m" || interval === "30m" || interval === "5m") days = 5;
  else days = 30;

  const now = Math.floor(Date.now() / 1000);
  return { period1: now - days*24*60*60, period2: now };
}

export async function fetchCandles(ticker, interval = "15m") {
  if (!ticker || !String(ticker).trim()) {
    console.error("1 Failed download:\n['']: Empty ticker");
    return [];
  }
  const { period1, period2 } = computePeriod(interval);
  try {
    const res = await yahooFinance.chart(ticker, { interval, period1, period2 });
    const candles = (res?.quotes || [])
      .map(q => ({ t: new Date(q.date).getTime(), o: q.open, h: q.high, l: q.low, c: q.close, v: q.volume }))
      .filter(x => Number.isFinite(x.c));
    if (!candles.length) throw new Error("empty-candles");
    return candles;
  } catch (e) {
    const msg = String(e?.message || e);
    if (/(Too Many Requests|429|rate)/i.test(msg)) {
      console.error(`1 Failed download:\n['${ticker}']: RateLimited('Too Many Requests. Try after a while.')`);
    } else {
      console.error(`1 Failed download:\n['${ticker}']: ${msg}`);
    }
    return [];
  }
}
