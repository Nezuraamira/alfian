import axios from "axios";
import axiosRetry from "axios-retry";
import https from "https";

export function makeClient(timeoutMs = 25000, verify = true) {
  const instance = axios.create({
    timeout: timeoutMs,
    httpsAgent: verify ? undefined : new https.Agent({ rejectUnauthorized: false }),
    headers: { "User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)" }
  });
  axiosRetry(instance, {
    retries: 4,
    retryDelay: (count, err) => {
      const s = err?.response?.status;
      const base = axiosRetry.exponentialDelay(count, err);
      const wait = base + Math.floor(Math.random() * 500);
      if (s === 429) {
        const ra = Number(err?.response?.headers?.["retry-after"] || 0) * 1000 || 0;
        const w = Math.max(wait, ra);
        console.error(`RateLimit 429 -> retry in ${Math.round(w/1000)}s`);
        return w;
      }
      return wait;
    },
    retryCondition: (e) => {
      const s = e?.response?.status;
      return axiosRetry.isNetworkOrIdempotentRequestError(e) || [429,500,502,503,504].includes(s);
    }
  });
  return instance;
}

export async function safeGet(url, { timeoutMs = 25000, verify = true, params } = {}) {
  try {
    const c = makeClient(timeoutMs, verify);
    console.log(`[HTTP] GET ${url}`);
    const res = await c.get(url, { params });
    console.log(`[HTTP] ${res.status} ${url}`);
    return res;
  } catch (e) {
    const s = e?.response?.status;
    if (s === 429) console.error(`RateLimit('Too Many Requests') at ${url}`);
    else console.error(`RequestFailed('${e?.message || "unknown"}') at ${url}`);
    return null;
  }
}
