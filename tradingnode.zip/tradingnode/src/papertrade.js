import fs from "fs";
const FILE = "trades.json";
export function saveTrade(t){
  let a=[]; if (fs.existsSync(FILE)){ try{ a=JSON.parse(fs.readFileSync(FILE,'utf8')) } catch{ a=[] } }
  a.push({ ...t, result:"OPEN" }); fs.writeFileSync(FILE, JSON.stringify(a,null,2));
}
