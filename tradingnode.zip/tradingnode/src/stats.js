import fs from "fs";
const FILE = "trades.json";
export function appendTrade(t){
  let a=[]; if (fs.existsSync(FILE)){ try{ a = JSON.parse(fs.readFileSync(FILE,'utf8')) } catch{ a=[] } }
  a.push(t); fs.writeFileSync(FILE, JSON.stringify(a,null,2));
}
export function summary(hours=12){
  if (!fs.existsSync(FILE)) return { total:0, win:0, loss:0, be:0, wr:0 };
  let a=[]; try{ a = JSON.parse(fs.readFileSync(FILE,'utf8')) } catch{}
  const since = Date.now()-hours*3600*1000;
  const rec = a.filter(x=> new Date(x.time_utc).getTime()>=since);
  const total = rec.length, win=rec.filter(x=>x.result==='WIN').length,
        loss=rec.filter(x=>x.result==='LOSS').length, be=rec.filter(x=>x.result==='BE').length;
  const wr = total? Math.round(100*win/total):0;
  return { total, win, loss, be, wr };
}
