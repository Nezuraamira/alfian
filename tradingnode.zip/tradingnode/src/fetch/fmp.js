import config from "../config.js";
import { safeGet } from "../httpClient.js";

export async function fetchFmp(days=3){
  console.log(`Fetch FMP: ${config.FMP_CALENDAR_URL}`);
  const end = new Date(); const start = new Date(end.getTime()-days*24*60*60*1000);
  const p = d => d.toISOString().slice(0,10);
  const r = await safeGet(config.FMP_CALENDAR_URL, { verify:true, params:{ from:p(start), to:p(end), apikey: config.FMP_API_KEY }});
  if (!r || r.status !== 200){
    console.error(`1 Failed download:\n['FMP']: ${r ? `HTTPError(${r.status})` : "NetworkError/RateLimited"}`);
    return [];
  }
  const data = Array.isArray(r.data) ? r.data : [];
  return data.map(it => ({
    source:"fmp",
    timestamp: it.date || null,
    country: it.country || "",
    title: it.event || "",
    impact: it.impact || "",
    actual: it.actual ?? null,
    forecast: it.estimate ?? it.forecast ?? null,
    previous: it.previous ?? null
  }));
}
