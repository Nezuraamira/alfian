import config from "../config.js";
import { safeGet } from "../httpClient.js";

export async function fetchDailyfx() {
  console.log(`Fetch DailyFX: ${config.DAILYFX_URL}`);
  const r = await safeGet(config.DAILYFX_URL, { verify: true });
  if (!r || r.status !== 200) {
    console.error(`1 Failed download:\n['DailyFX']: ${r ? `HTTPError(${r.status})` : "NetworkError/RateLimited"}`);
    return [];
  }
  const data = Array.isArray(r.data) ? r.data : (r.data?.events || []);
  return data.map(it => ({
    source: "dailyfx",
    timestamp: it.date || it.timestamp || null,
    country: it.country || "",
    title: it.title || it.event || "",
    impact: it.importance || it.impact || "",
    actual: it.actual ?? null,
    forecast: it.forecast ?? null,
    previous: it.previous ?? null
  }));
}
