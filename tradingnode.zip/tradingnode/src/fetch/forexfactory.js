import * as cheerio from "cheerio";
import config from "../config.js";
import { safeGet } from "../httpClient.js";

export async function fetchForexfactory(){
  console.log(`Fetch ForexFactory: ${config.FF_URL}`);
  const r = await safeGet(config.FF_URL, { verify: config.FF_VERIFY_SSL });
  if (!r || r.status !== 200){
    console.error(`1 Failed download:\n['ForexFactory']: ${r ? `HTTPError(${r.status})` : "NetworkError/RateLimited"}`);
    return [];
  }
  const $ = cheerio.load(r.data);
  const out = [];
  $("tr").slice(0,400).each((_,el)=>{
    const row = $(el);
    const time = row.find(".calendar__time, .time").text().trim();
    const title = row.find(".calendar__event, .event").text().trim();
    const impact = row.find(".calendar__impact, .impact").text().trim();
    const actual = row.find(".calendar__actual, .actual").text().trim();
    const forecast = row.find(".calendar__forecast, .forecast").text().trim();
    const previous = row.find(".calendar__previous, .previous").text().trim();
    if (title) out.push({
      source:"forexfactory", timestamp: time||null, country:"",
      title: title.substring(0,140), impact: impact || "n/a",
      actual: actual || null, forecast: forecast || null, previous: previous || null
    });
  });
  return out;
}
