import config from "./config.js";
import { fetchCandles } from "./yahoo.js";
import { ema, rsi, macd, atr } from "./indicators.js";

export async function analyzePair(ticker){
  console.log(`[CHECK] ${ticker} — start`);

  // Daily: trend filter
  const d = await fetchCandles(ticker, '1d');
  if (d.length < 210) return { ticker, ok:false, reason:"insufficient daily data" };
  const dClose = d.map(x=>x.c);
  const dEMA200 = ema(dClose, 200);
  const trendUp = dClose.at(-1) > dEMA200.at(-1);
  console.log(`[DATA] ${ticker} D1 trend=${trendUp?'UP':'DOWN'} close=${dClose.at(-1).toFixed(5)} ema200=${dEMA200.at(-1).toFixed(5)}`);

  // H1: momentum
  const h1 = await fetchCandles(ticker, '1h');
  if (!h1.length) return { ticker, ok:false, reason:"no 1h data" };
  const hc = h1.map(x=>x.c);
  const m = macd(hc); const r = rsi(hc, 14);
  const macdUp = m.macdLine.at(-2) < m.signalLine.at(-2) && m.macdLine.at(-1) > m.signalLine.at(-1);
  const macdDn = m.macdLine.at(-2) > m.signalLine.at(-2) && m.macdLine.at(-1) < m.signalLine.at(-1);
  console.log(`[DATA] ${ticker} H1 macd=${(m.macdLine.at(-1)-m.signalLine.at(-1)).toFixed(5)} rsi=${r.at(-1).toFixed(2)}`);

  // M15: trigger
  const m15 = await fetchCandles(ticker, '15m');
  if (!m15.length) return { ticker, ok:false, reason:"no 15m data" };
  const mc = m15.map(x=>x.c);
  const ema20 = ema(mc,20);
  const crossUp = mc.at(-2) < ema20.at(-2) && mc.at(-1) > ema20.at(-1);
  const crossDn = mc.at(-2) > ema20.at(-2) && mc.at(-1) < ema20.at(-1);

  const nowTs = m15.at(-1).t;
  const ageSec = (Date.now()-nowTs)/1000;
  if (config.STRICT_BAR_CLOSE && ageSec > config.STALE_MAX_SEC){
    return { ticker, ok:false, reason:`stale bar ${Math.round(ageSec)}s` };
  }

  const HATR = atr(h1,14).at(-1) || (h1.at(-1).h - h1.at(-1).l);
  const last = mc.at(-1);

  let side = "NONE";
  if (trendUp && macdUp && r.at(-1) >= 50 && crossUp) side="BUY";
  if (!trendUp && macdDn && r.at(-1) <= 50 && crossDn) side="SELL";
  if (side==="NONE") return { ticker, ok:false, reason:"no setup" };

  const sl = side==="BUY" ? last - 1.2*HATR : last + 1.2*HATR;
  const tp = side==="BUY" ? last + 1.8*HATR : last - 1.8*HATR;
  const confidence = Math.min(99, Math.max(51, Math.round(60 + (r.at(-1)-50))));

  console.log(`[SIGNAL] ${ticker} ${side} entry=${last.toFixed(5)} sl=${sl.toFixed(5)} tp=${tp.toFixed(5)} conf=${confidence}%`);
  return { ticker, ok:true, side, entry:last, sl, tp, confidence, time_utc: new Date().toISOString() };
}
