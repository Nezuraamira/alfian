// Auto-generated from config.py (Python)
export default {
  "PAIRS": [
  "EURUSD=X",
  "GBPUSD=X",
  "USDJPY=X",
  "CG=F",      // Gold spot (stabil)
  "AUDUSD=X",
  "USDCAD=X"
],
  "HEARTBEAT_INTERVAL": 300,
  "WAIT_MINUTES": 15,
  "PERIODIC_SUMMARY_HOURS": 12,
  "STALE_SECS": 90,
  "STRICT_BAR_CLOSE": true,
  "NEWS_FEEDS_ENABLED": {
    "dailyfx": true,
    "forexfactory": true,
    "fmp": false
  },
  "DAILYFX_URL": "",
  "FF_URL": "https://www.forexfactory.com/calendar?week=this",
  "FF_VERIFY_SSL": false,
  "FMP_CALENDAR_URL": "https://financialmodelingprep.com/api/v3/economic_calendar",
  "FMP_API_KEY": "6LPEaGkgilCljzIhMCkNEdk4KaOO18bo",
  "LOG_PREFIX": "[BOT]"
};
