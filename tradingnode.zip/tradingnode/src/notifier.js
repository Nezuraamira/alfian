import axios from "axios";
import { DISCORD_WEBHOOK_SIGNALS, DISCORD_WEBHOOK_NEWS, DISCORD_WEBHOOK_LOG } from "./secrets.js";

async function post(hook, content) {
  if (!hook) return;
  try { await axios.post(hook, { content }); }
  catch (e) { console.error("[WEBHOOK] fail", e?.response?.status || e?.message); }
}

export const sendSignal = (msg) => post(DISCORD_WEBHOOK_SIGNALS, msg);
export const sendNews   = (msg) => post(DISCORD_WEBHOOK_NEWS, msg);
export const sendLog    = (msg) => post(DISCORD_WEBHOOK_LOG, msg);
